<?php
require_once('db.php');

function addfavourite($title, $author, $isbn, $available_copies){
    $conn = getConnection();
    $title = mysqli_real_escape_string($conn, $title);
    $author = mysqli_real_escape_string($conn, $author);
    $isbn = mysqli_real_escape_string($conn, $isbn);
    $available_copies = mysqli_real_escape_string($conn, $available_copies);
    $sql = "INSERT INTO favourite (title, author, isbn, available_copies) VALUES ('$title', '$author', '$isbn', '$available_copies')";
    $status = mysqli_query($conn, $sql);
    mysqli_close($conn);
    return $status;
}

function getfavourites() {
    $conn = getConnection();
    $sql = "SELECT * FROM favourite";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Error retrieving favourites: " . mysqli_error($conn));
    }

    $favourites = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $favourites[] = $row;
    }

    mysqli_close($conn);
    return $favourites;
}

function borrowfavourite($id, $user){
    $conn = getConnection();
    $id = mysqli_real_escape_string($conn, $id);
    $user = mysqli_real_escape_string($conn, $user);
    $sql_borrow = "INSERT INTO borrow_return (favourite_id, user, borrow_date) VALUES ('$id', '$user', NOW())";
    $sql_update = "UPDATE favourite SET available_copies = available_copies - 1 WHERE id = '$id' AND available_copies > 0";
    $status_borrow = mysqli_query($conn, $sql_borrow);
    $status_update = mysqli_query($conn, $sql_update);
    mysqli_close($conn);
    return $status_borrow && $status_update;
}

function returnfavourite($id, $user){
    $conn = getConnection();
    $id = mysqli_real_escape_string($conn, $id);
    $user = mysqli_real_escape_string($conn, $user);
    $sql_return = "UPDATE borrow_return SET return_date = NOW() WHERE favourite_id = '$id' AND user = '$user' AND return_date IS NULL";
    $sql_update = "UPDATE favourite SET available_copies = available_copies + 1 WHERE id = '$id'";
    $status_return = mysqli_query($conn, $sql_return);
    $status_update = mysqli_query($conn, $sql_update);
    mysqli_close($conn);
    return $status_return && $status_update;
}
?>