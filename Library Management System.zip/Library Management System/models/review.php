<?php
require_once 'db.php';

function addReview($book_name, $rating, $review, $email) {
    $con = getConnection();
    $book_name = mysqli_real_escape_string($con, $book_name);
    $rating = mysqli_real_escape_string($con, $rating);
    $review = mysqli_real_escape_string($con, $review);
    $email = mysqli_real_escape_string($con, $email);
    $sql = "INSERT INTO reviews (book_name, rating, review, email) VALUES ('$book_name', '$rating', '$review', '$email')";
    $status = mysqli_query($con, $sql);
    mysqli_close($con);
    return $status;
}

function getReviews() {
    $conn = getConnection();
    $sql = "SELECT * FROM reviews";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Error retrieving reviews: " . mysqli_error($conn));
    }

    $reviews = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $reviews[] = $row;
    }

    mysqli_close($conn);
    return $reviews;
}
?>
