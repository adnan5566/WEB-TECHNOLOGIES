<?php

require_once 'db.php';

function addFine($payment_method, $phone_number, $amount, $pin)
{
    $con = getConnection();
    $payment_method = mysqli_real_escape_string($con, $payment_method);
    $phone_number = mysqli_real_escape_string($con, $phone_number);
    $amount = mysqli_real_escape_string($con, $amount);
    $pin = mysqli_real_escape_string($con, $pin);

    $sql = "INSERT INTO fines (payment_method, phone_number, amount, pin) VALUES ('$payment_method', '$phone_number', '$amount', '$pin')";
    $status = mysqli_query($con, $sql);
    mysqli_close($con);
    return $status;
}

function getFines() {
    $conn = getConnection();
    $sql = "SELECT * FROM fines";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Error retrieving fines: " . mysqli_error($conn));
    }

    $fines = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $fines[] = $row;
    }

    mysqli_close($conn);
    return $fines;
}

?>
