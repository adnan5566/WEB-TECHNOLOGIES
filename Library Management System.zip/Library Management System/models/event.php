<?php

require_once 'db.php';

class Event {
    public function createEvent($title, $description) {
        $conn = getConnection();
        $sql = "INSERT INTO Events (title, description) VALUES ('$title', '$description')";
        $result = mysqli_query($conn, $sql);
        mysqli_close($conn);
        return $result;
    }

    public function getEvents() {
        $conn = getConnection();
        $sql = "SELECT * FROM events";
        $result = mysqli_query($conn, $sql);
        $Events = mysqli_fetch_all($result, MYSQLI_ASSOC);
        mysqli_close($conn);
        return $Events;
    }
}

?>
