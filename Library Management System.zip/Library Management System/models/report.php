<?php

require_once 'db.php';

class report {
    public function createReport($title, $description) {
        $conn = getConnection();
        $sql = "INSERT INTO reports (title, description) VALUES ('$title', '$description')";
        $result = mysqli_query($conn, $sql);
        mysqli_close($conn);
        return $result;
    }

    public function getreports() {
        $conn = getConnection();
        $sql = "SELECT * FROM reports";
        $result = mysqli_query($conn, $sql);
        $reports = mysqli_fetch_all($result, MYSQLI_ASSOC);
        mysqli_close($conn);
        return $reports;
    }
}

?>