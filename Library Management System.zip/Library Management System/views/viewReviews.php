<!DOCTYPE html>
<html>
<head>
    <title>View Reviews</title>
    <link rel="stylesheet" href="viewReviews.css">
</head>
<body>
    <h1>View Reviews</h1>
    <table>
        <tr>
            <th>Book Name</th>
            <th>Rating</th>
            <th>Review</th>
            <th>Email</th>
        </tr>
        <?php
            require_once '../models/review.php';
            $reviews = getReviews();
            foreach ($reviews as $review) { 
                echo "<tr>";
                echo "<td>" . $review['book_name'] . "</td>";
                echo "<td>" . $review['rating'] . "</td>";
                echo "<td>" . $review['review'] . "</td>";
                echo "<td>" . $review['email'] . "</td>";
                echo "</tr>";
            }
        ?>
    </table>
</body>
</html>
