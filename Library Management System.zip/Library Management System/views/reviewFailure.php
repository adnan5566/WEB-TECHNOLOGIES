<!DOCTYPE html>
<html>
<head>
    <title>Review Failure</title>
    <link rel="stylesheet" href="reviewFailure.css">
</head>
<body>
    <h1>Review Submission Failed</h1>
    <p>There was an error while submitting your review. Please try again.</p>
    <a href="addReview.php">Try again</a>
</body>
</html>
