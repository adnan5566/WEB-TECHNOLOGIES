<!DOCTYPE html>
<html>
	<head>
		<title>Library Management System Email Support</title>
		<link rel="stylesheet" href="email.css">
	</head>
	<body>
		<fieldset>
		
			<legend><h1>Email Support</h1></legend>
				<table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
			<p>If you have any questions or issues related to the Library Management System, please don't hesitate to contact us by email.</p>
		
			<fieldset>
			<legend><h2>Send Email</h2></legend>

		<table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
        </table>

			<form name="emailForm" method="post" action="../../controllers/send_email.php" onsubmit="return validateForm()">
				<label for="name">Name:</label>
				<input type="text" id="name" name="name"><br>

				<label for="email">Email:</label>
				<input type="email" id="email" name="email"><br>

				<label for="subject">Subject:</label>
				<input type="text" id="subject" name="subject"><br>

				<label for="message">Message:</label>
				<textarea id="message" name="message" rows="5" cols="30"></textarea><br>

				<input type="button" name="click" value="Check" onclick="ajax()">
				<input type="submit" value="Send">
				<input type="reset" value="Reset"><br/>
			</form>
			</fieldset>

		</fieldset>
	</body>
</html>




	<script>
		function validateForm() {
    	var name = document.emailForm.name.value;
    	var email = document.emailForm.email.value;
    	var subject = document.emailForm.subject.value;
    	var message = document.emailForm.message.value;


		let nameVal = /^[a-zA-Z]+$/;
        let emailVal = /^\S+@\S+\.\S+$/;

        if (name == "" || !nameVal.test(name)) {
        	alert("Please enter a valid name (A-Z characters only)");
        	return false;
    	}

    	if (email == "" || !emailVal.test(email)) {
            alert("Please enter a valid email address");
            return false;
        }
    	if (subject == "" || subject.length < 1) {
        	alert("Please enter the subject");
        	return false;
    	}

    	if (message == "" || message.trim().length < 1) {
        	alert("Please enter your message");
        	return false;
    	}
    	return true;
		}


		function ajax (){
			var name = document.emailForm.name.value;
    		var email = document.emailForm.email.value;
    		var subject = document.emailForm.subject.value;
    		var message = document.emailForm.message.value;
			let data = {
				 'name' : name,
				 'email' :email,
				 'subject' : subject,
				 'message' : message};


			let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="name : "+info.name;
                document.getElementsByTagName('h2')[1].innerHTML ="email : " +info.email;
                document.getElementsByTagName('h2')[2].innerHTML ="subject : "+info.subject;
                document.getElementsByTagName('h2')[3].innerHTML ="message :" +info.message;
			}
		}

	}

	</script>
		


