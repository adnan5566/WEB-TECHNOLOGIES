<!DOCTYPE html>
<html>
    <head>
        <title>Feedback</title>
        <link rel="stylesheet" href="feedback.css">
    </head>
    <body>
        <fieldset>
            <legend><h1>Feedback</h1></legend>
            <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            </table>

        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            
        </table>

            <form name="feedbackForm" method="post" action="../../controllers/feedbacksubmit.php" onsubmit="return validateForm()">
                <label>Name:</label>
                <input type="text" name="name"><br/>
                <label>Email:</label>
                <input type="email" name="email"><br/>
                <label>Feedback:</label>
                <textarea name="feedback" rows="5" cols="30"></textarea><br/>
                
				<input type="button" name="click" value="Check" onclick="ajax()">
				<input type="submit" value="Send">
				<input type="reset" value="Reset"><br/>
            </form>
        </fieldset>
    </body>
</html>



    <script>
        function validateForm() {
            var name = document.feedbackForm.name.value;
            var email = document.feedbackForm.email.value;
            var feedback = document.feedbackForm.feedback.value;

            let nameVali = /^[a-zA-Z]+$/;
            let emailVal = /^\S+@\S+\.\S+$/;

            if (name == "" || !nameVali.test(name)) {
        	    alert("Please enter a valid name (A-Z characters only)");
        	return false;
    	    }

    	    if (email == "" || !emailVal.test(email)) {
                alert("Please enter a valid email address");
            return false;
            }
            if (feedback.trim().length < 1) {
        	    alert("Please enter your message");
        	return false;
    	    }

                return true;
            }



            function ajax (){
                var name = document.feedbackForm.name.value;
                var email = document.feedbackForm.email.value;
                var feedback = document.feedbackForm.feedback.value;
			    
                
                let data = {
				 'name' : name,
				 'email' :email,
				 'feedback' : feedback};


			let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="name : "+info.name;
                document.getElementsByTagName('h2')[1].innerHTML ="email : " +info.email;
                document.getElementsByTagName('h2')[2].innerHTML ="feedback :" +info.feedback;
			}
		}

	}

    //     function ajax() {
    //         var name = document.feedbackForm.name.value;
    //         var email = document.feedbackForm.email.value;
    //         var feedback = document.feedbackForm.feedback.value;  
            
    //         let data ={
    //             'name' : name;
    //             'email' : email;
    //             'feedback' : feedback;
    //         }

    //         let info = JSON.stringify(data);
    //         let xhttp = new XMLHttpRequest();

    //         xhttp.open('post', 'server.php', true);
    //     xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    //     xhttp.send('data=' + info);

    //     xhttp.onreadystatechange = function() {

    //         if (this.readyState == 4 && this.status == 200) {

    //             let info = JSON.parse(this.responseText);
    //             document.getElementsByTagName('h2')[0].innerHTML ="Account Number: "+info.accno;
    //             document.getElementsByTagName('h2')[1].innerHTML ="Bank" +info.bank;
    //             document.getElementsByTagName('h2')[2].innerHTML = info.amount+" Tk";
    //         }
    //     }

    // }

        
    </script>
