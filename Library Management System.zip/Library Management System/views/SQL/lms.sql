-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2023 at 03:06 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `catalogresource`
--

CREATE TABLE `catalogresource` (
  `bookname` varchar(20) NOT NULL,
  `authorname` varchar(20) NOT NULL,
  `publishyear` year(4) NOT NULL,
  `publisher` varchar(20) NOT NULL,
  `isbn` int(20) NOT NULL,
  `CIPN` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catalogresource`
--

INSERT INTO `catalogresource` (`bookname`, `authorname`, `publishyear`, `publisher`, `isbn`, `CIPN`) VALUES
('Adnan', 'Sir', 0000, 'Ad ', 199956, 11),
('Ad', 'Adn', 0000, 'AD', 199954, 14),
('Ad', 'Adn', 2004, 'AD', 199954, 14),
('', '', 0000, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `catalogresource1`
--

CREATE TABLE `catalogresource1` (
  `title` varchar(20) NOT NULL,
  `publisher` varchar(20) NOT NULL,
  `volume` int(20) NOT NULL,
  `issue` int(11) NOT NULL,
  `CIPN` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catalogresource1`
--

INSERT INTO `catalogresource1` (`title`, `publisher`, `volume`, `issue`, `CIPN`) VALUES
('0', '0', 10, 0, 11),
('adnan', 'xvxsvb', 10, 0, 13),
('adnan', 'xvxsvb', 10, 0, 13),
('adnan', 'xvxsvb', 10, 0, 13),
('adnan', 'xvxsvb', 10, 0, 13),
('adnan', 'xvxsvb', 10, 0, 13),
('zxmncmkzxn', 'ss', 10, 20230409, 13),
('zxmncmkzxn', 'ss', 10, 2023, 13);

-- --------------------------------------------------------

--
-- Table structure for table `emailsupport`
--

CREATE TABLE `emailsupport` (
  `name` text NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emailsupport`
--

INSERT INTO `emailsupport` (`name`, `email`, `subject`, `message`) VALUES
('adnan', 'adnan77@gmial.com', 'asvsv', 'sdafhsjkdhafjkhgasdkjfjksdjka'),
('mohish', 'mohish@gmail.com', 'product_db', 'product_db'),
('mohish', 'mohish@gmail.com', 'product_db', 'product_db'),
('mohish', 'mohish@gmail.com', 'product_db', 'product_db'),
('adnan', 'adnan77@gmial.com', 'hi', 'i have facing problem'),
('enan', 'enan@gmail.com', 'jdfkljlkdf', 'sdlfnkljsdhgklhasd'),
('adnan', 'adnan77.aiub@gmail.c', 'ddshebdueg', 'euqhduiqhwjidb'),
('Adnan', 'mahian@gmail.com', 'ss', 'k.');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `feedback`) VALUES
('ovi', 'ovi@gmail.com', 'ttggtft'),
('ovi', 'ovi@gmail.com', 'ttggtft'),
('mohish', 'mohish@gmail.com', 'ijdfsbsdbhs'),
('mohish', 'mohish@gmail.com', 'ijdfsbsdbhs'),
('enan', 'enan@gmail.com', 'jbuighui'),
('Samir', 'samir909668@gmail.co', 'l'),
('Samir', 'samir909668@gmail.co', 'l');

-- --------------------------------------------------------

--
-- Table structure for table `librarycardbd`
--

CREATE TABLE `librarycardbd` (
  `userid` varchar(6) NOT NULL,
  `lc_id` varchar(6) NOT NULL,
  `status` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `librarycardbd`
--

INSERT INTO `librarycardbd` (`userid`, `lc_id`, `status`) VALUES
('U-6433', 'LC-040', 'active'),
('U-6340', 'LC-112', 'active'),
('U-9668', 'LC-809', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Lc_id` varchar(10) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `reason` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `phone_number` int(14) NOT NULL,
  `pin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Lc_id`, `payment_method`, `reason`, `amount`, `phone_number`, `pin`) VALUES
('LC-0710', 'bkash', 'buy_books', 1002, 1635265565, 1111),
('LC-0710', 'bkash', 'buy_books', 1002, 1635265565, 1111),
('LC-0710', 'bkash', 'buy_books', 1002, 1635265565, 1111),
('LC-0710', 'bkash', 'buy_books', 1002, 1635265565, 1111),
('LC-6094', 'nagad', 'lost_book', 1110, 1635265565, 1111),
('LC-6094', 'nagad', 'fine', 115, 1635265565, 1213),
('LC-6094', 'nagad', 'buy_books', 100, 1518358088, 1111),
('LC-0710', 'rocket', 'buy_books', 1500, 1813438784, 1111);

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `type` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `author` varchar(20) NOT NULL,
  `year` int(20) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`type`, `title`, `author`, `year`, `quantity`) VALUES
('book', 'adnan', 'ad', 2022, 50),
('journal', 'adnan', 'ad', 2022, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userdb`
--

CREATE TABLE `userdb` (
  `userid` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `dob` datetime(6) NOT NULL,
  `password` varchar(20) NOT NULL,
  `contactnumber` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userdb`
--

INSERT INTO `userdb` (`userid`, `name`, `email`, `dob`, `password`, `contactnumber`) VALUES
('L-1234', 'Joy', 'joy@gmail.com', '0000-00-00 00:00:00.000000', '1111', '01111111111'),
('U-0068', 'Emran', 'em@gmail.com', '2023-04-02 00:00:00.000000', '1111', '01635265565'),
('U-0952', 'adnan', 'adnan77.aiub@gmail.c', '2023-04-06 00:00:00.000000', '1111', '01813438784'),
('U-1215', 'ovi', 'ovi@gmail.com', '2023-04-02 00:00:00.000000', '1111', '01222222222'),
('U-2145', 'tafsir', 'tafsir@gmail.com', '2023-04-02 00:00:00.000000', '1111', '018382823887346'),
('U-3588', 'ad', 'aj@gmail.com', '2023-04-03 00:00:00.000000', '11111', '01333333333'),
('U-4320', 'mohish', 'mohish@gmail.com', '2023-04-02 00:00:00.000000', '1111', '0111111111111'),
('U-4577', 'enan', 'enan@gmail.com', '2023-04-01 00:00:00.000000', '1111', '01518358088'),
('U-5349', 'bushra', 'bushra@gmail.com', '2003-12-15 00:00:00.000000', '1111', '01643541661'),
('U-6012', 'Juwel1', 'juwel1@gmail.com', '2023-04-02 00:00:00.000000', '1111', '01716309513'),
('U-6340', 'md shamim', 'shamim@gmail.com', '2023-04-09 00:00:00.000000', '123', '84'),
('U-6433', 'ovi', 'ovi@gmail.com1', '2023-04-09 00:00:00.000000', '1111', '01635265565'),
('U-6873', 'To', 'ta@gmail.com', '2023-04-09 00:00:00.000000', '1111', '0813438784'),
('U-7533', 'Tonmoy', 'td@gmail.com', '2023-04-09 00:00:00.000000', '1111', '0813438784'),
('U-9668', 'mohish', 'mohish1@gmail.com', '2023-04-01 00:00:00.000000', '1111', '0813438784');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userdb`
--
ALTER TABLE `userdb`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `userid` (`userid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `userid_2` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
