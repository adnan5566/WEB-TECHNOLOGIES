<!DOCTYPE html>
	<html>
		<head>
			<title>Library Management System | Adnan</title>
			<link rel="stylesheet" href="LMS.css">
		</head>
			<body>					
				<fieldset>
					<table width = "800">
                        <tr>
                            <td>
                                <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                            </td>
                        </tr>    
                	</table>
					<legend><h1>| User DashBoard |</h1></legend>
					<form>  
						<hr>
						<p> <a href="../views/Legal Aggrement Feature/Legal-agg.php"><b>Legal Aggrement</b></a> </p>
						<hr>
						<p> <a href="../views/Library Card/Library Card.php"><b>Library Card</b></a> </p>
						<hr>
						<p> <a href="../views/Help & Support/Help & Support.php"><b>Help & Support</b></a> </p>
						<hr>
						<p> <a href="../views/Payment/Payment.php"><b>Payment</a></b></p>
						<hr>
						<p> <a href="../views\ViewProfile\MemberInformationView.php"><b>  View Information <b></a></p>
						<hr>
						<p><a href="Trending\mostPolularBook\mostpopularbook.php"><b> Most Popular Book </b></a></p>
						<hr>
						<p><a href="search_publication.php"><b>Search</b></a></p>
						<hr>
						<p><a href="reservation.php"> <b>Insert Reservation</b></a></p>
						<hr>
						<p><a href="display.php"><b>Item Available</b></a></p>
						<hr>
						<p><a href="reservation_check_publication.php"><b>Reservation Check</a></p>
						<hr>
						<p><a href="viewNotification.php"><b>View Notification</b></a></p>
						<hr>
						<p><a href="borrow_return.php"><b>Borrow and Return</b></a></p>
						<hr>
						<p><a href="addReview.php"><b>Review</b></a></p>
						<hr>
						<p><a href="addFine.php"><b>Fine</b></a></p>
						<hr>
						<p><a href="createReport.php"><b>Create Report</b></a></p>
						<p><a href="viewReport.php"><b>* View Report</b></a></p>
						<hr>
						<p><a href="addfavourite.php"><b>Favourite</b></a></p>
						<hr>
            			<p><a href="../controllers/logout.php"><b> LogOut </b></a></p>
						<hr>
					</form>
				</fieldset>	
			</body>
	</html>