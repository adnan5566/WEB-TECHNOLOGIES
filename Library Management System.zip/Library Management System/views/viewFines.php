<!DOCTYPE html>
<html>
<head>
    <title>View Fines</title>
    <link rel="stylesheet" href="viewFine.css">
</head>
<body>
    <fieldset>
        <legend><h1>View Fines</h1></legend>
    <table>
        <tr>
            <th>Payment Method</th>
            <th>Phone Number</th>
            <th>Amount</th>
        </tr>
        <?php
            require_once '../models/fine.php';
            $fines = getFines();
            foreach ($fines as $fine) {
                echo "<tr>";
                echo "<td>" . $fine['payment_method'] . "</td>";
                echo "<td>" . $fine['phone_number'] . "</td>";
                echo "<td>" . $fine['amount'] . "</td>";
                echo "</tr>";
            }
        ?>
    </table>
    </fieldset>
</body>
</html>
