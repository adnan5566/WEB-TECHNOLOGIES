<!DOCTYPE html>
<html>
<head>
    <title>Add Review</title>
    <link rel="stylesheet" href="addReview.css">
    <script>
        function validateForm() {
            const book_name = document.reviewForm.book_name;
            const rating = document.reviewForm.rating;
            const review = document.reviewForm.review;
            const email = document.reviewForm.email;

            if (book_name.value.trim() === "") {
                alert("Book Name must be filled out");
                book_name.focus();
                return false;
            }

            if (rating.value.trim() === "" || rating.value < 1 || rating.value > 5) {
                alert("Rating must be filled out and between 1 and 5");
                rating.focus();
                return false;
            }

            if (review.value.trim() === "") {
                alert("Review must be filled out");
                review.focus();
                return false;
            }

            if (email.value.trim() === "") {
                alert("Email must be filled out");
                email.focus();
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h1>Add Review</h1>
    <form name="reviewForm" action="../controllers/reviewController.php" method="post" onsubmit="return validateForm()">
        <label for="book_name">Book Name:</label>
        <input type="text" id="book_name" name="book_name">
        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" min="1" max="5">
        <label for="review">Review:</label>
        <textarea id="review" name="review"></textarea>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email">
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
