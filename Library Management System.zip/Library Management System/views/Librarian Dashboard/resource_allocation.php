<!DOCTYPE html>
<html>
<head>
    <title>Resource Allocation</title>
    <link rel="stylesheet" href="LibrarianDashboard.css">
</head>

<body>
    <fieldset>
        <legend><h1>Resource Allocation</h1></legend>
        	<table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>

        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
        </table>

        <form method="post" action="../../controllers/allocationHendlar.php" onsubmit="return validateForm()">
            <b>
            <label for="type"><b>Select resource type:</b></label>

            <select name="type" id="type">
                <option value="book"><b>Book</b></option>
                <option value="journal"><b>Journal</b></option>
            </select><br/>

            <hr>

            <label for="title"><b>Title:</b></label>
            <input type="text" name="title" id="title"><br/>

            <hr>

            <label for="author"><b>Author:</b></label>
            <input type="text" name="author" id="author"><br/>

            <hr>

            <label for="year"><b>Year:</b></label>
            <input type="text" name="year" id="year"><br/>

            <hr>

            <label for="quantity"><b>Quantity:</b></label>
            <input type="number" name="quantity" id="quantity"><br/>

            <hr>
            <input type="button" name="click" value="Check" onclick="ajax()">
            <input type="submit" value="Submit">
            <input type="reset" value="Reset"><br/>
            <a href="Librarian-Dashboard.php"><button class="back-button" type="button">Back</button></a>
        </form>
    </fieldset>
	</body>
</html>

    <script>
        function validateForm() {
            var title = document.getElementById("title").value;
            var author = document.getElementById("author").value;
            var year = document.getElementById("year").value;
            var quantity = document.getElementById("quantity").value;

            if (title == "" || title.length < 1 ) {
                alert("Title must contain at least one words");
                return false;
            }
            if (author == "" || author.length < 2) {
                alert("Author name must contain at least one words");
                return false;
            }
            if (year == "" || year < 1900) {
                alert("Please enter a valid year");
                return false;
            }

            if (quantity == "" || quantity <5) {
                alert("Quantity must be a number and minimum 5");
                return false;
            }
            

            return true;
        }

        function ajax (){
            var title = document.getElementById("title").value;
            var author = document.getElementById("author").value;
            var year = document.getElementById("year").value;
            var quantity = document.getElementById("quantity").value;
            
            let data = {
                'title' : title,
                'author' : author,
                'year' : year,
                'quantity' : quantity

            };
            let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="title : "+info.title;
                document.getElementsByTagName('h2')[1].innerHTML ="author : " +info.author;
                document.getElementsByTagName('h2')[2].innerHTML ="year : "+info.year;
                document.getElementsByTagName('h2')[3].innerHTML ="quantity :" +info.quantity;
                
            }
        }

    }

    </script>

