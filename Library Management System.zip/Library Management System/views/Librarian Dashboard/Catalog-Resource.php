<!DOCTYPE html>
<html>
<head>
	<title>Catalog-Resource</title>
	<link rel="stylesheet" href="LibrarianDashboard.css">
</head>
<body>
	<fieldset>
	<legend><h1>Catalog-Resource </h1></legend>
			<table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>
	<form action="Librarian-Dashboard.php" method="post">
	<hr>
	<p> <a href="catalog_books.php"><h3>Books</h3></a> </p>
	<hr>
	<p> <a href="Catalog_Journals.php"><h3>Journals</h3></a> </p>
	<hr>
	
	
	
	<a href="Librarian-Dashboard.php"><button class="back-button" type="button">Back</button></a>
	</form>
	</fieldset>

</body>
</html>