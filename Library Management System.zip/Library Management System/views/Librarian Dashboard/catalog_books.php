<!DOCTYPE html>
<html>
  <head>
    <title>Book Cataloging System</title>
    <link rel="stylesheet" href="LibrarianDashboard.css">
  </head>

  <body>
    <fieldset>
      <legend>
        <h1>Book Cataloging System</h1></legend>
            <table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>
        <table>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
        	</table>
      <form name = "catalogbooksForm" method="post" action="../../controllers/catalog_booksHendlar.php" onsubmit="return validateForm()">
        <b>
          <label for="bookname"><b>Book Name:</b></label>
          <input type="text" id="bookname" name="bookname"><br/>
          <label for="authorname"><b>Author Name:</b></label>
          <input type="text" id="authorname" name="authorname"><br/>
          <label for="publishyear"><b>Published Year:</b></label>
          <input type="year" id="publishyear" name="publishyear"><br/>
          <label for="publisher"><b>Publisher:</b></label>
          <input type="text" id="publisher" name="publisher"><br/>
          <label for="isbn"><b>ISBN Number:</b></label>
          <input type="text" id="isbn" name="isbn"><br/>
          <label for="CIPN"><b>Cataloged In Page No.</b></label>
          <input type="text" id="CIPN" name="CIPN"><br/>
          <input type="button" name="click" value="Check" onclick="ajax()">
          <input type="submit" value="Submit">
        </b>
        <input type="reset" value="Reset">
        <a href="Catalog-Resource.php"><button class="back-button" type="button">Back</button></a>
      </form>
    </fieldset>
	</body>
</html>

    <script>
      function validateForm() {
        var bookName = document.catalogbooksForm.bookname.value;
        var authorName = document.catalogbooksForm.authorname.value;
        var publishYear = document.catalogbooksForm.publishyear.value;
        var publisher = document.catalogbooksForm.publisher.value;
        var isbn = document.catalogbooksForm.isbn.value;
        var cipn = document.catalogbooksForm.CIPN.value;

        if (bookName == null || bookName == "") {
          alert("Book Name must be filled out.");
          return false;
        }

        if (authorName == null || authorName == "") {
          alert("Author Name must be filled out.");
          return false;
        }

        if (publishYear == null || publishYear == "") {
          alert("Published Year must be filled out.");
          return false;
        }

        if (publisher == null || publisher == "") {
          alert("Publisher must be filled out.");
          return false;
        }

        if (isbn == null || isbn == "") {
          alert("ISBN Number must be filled out.");
          return false;
        }

        if (cipn == null || cipn == "") {
          alert("Cataloged In Page No. must be filled out.");
          return false;
        }

        return true;
      }


      function ajax (){
        var bookName = document.catalogbooksForm.bookname.value;
        var authorName = document.catalogbooksForm.authorname.value;
        var publishYear = document.catalogbooksForm.publishyear.value;
        var publisher = document.catalogbooksForm.publisher.value;
        var isbn = document.catalogbooksForm.isbn.value;
        var cipn = document.catalogbooksForm.CIPN.value;
            
            let data = {
                'bookName' : bookName,
                'authorName' : authorName,
                'publishYear' : publishYear,
                'publisher' : publisher,
                'isbn' : isbn,
                'cipn' :cipn

            };
            let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="bookname : "+info.bookName;
                document.getElementsByTagName('h2')[1].innerHTML ="authorName : " +info.authorName;
                document.getElementsByTagName('h2')[2].innerHTML ="publishyear : "+info.publishYear;
                document.getElementsByTagName('h2')[3].innerHTML ="publisher :" +info.publisher;
                document.getElementsByTagName('h2')[4].innerHTML ="isbn : "+info.isbn;
                document.getElementsByTagName('h2')[5].innerHTML ="cipn :" +info.cipn;
                
            }
        }

    }
    </script>

