<!DOCTYPE html>
    <html>
        <head>
            <title>Work Schedule</title>
            <link rel="stylesheet" href="LibrarianDashboard.css">
        </head>
        
        <body>
            <fieldset><legend><h1>Work Schedule</h1></legend>
            <table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>
            <form>
        <ul>
            <b>
            <li>Saturday: 9am-5pm</li>
            <hr>
            <li>Sunday: 9am-5pm</li>
            <hr>
            <li>Monday: 9am-5pm</li>
            <hr>
            <li>Tuesday: 9am-5pm</li>
            <hr>
            <li>Wednesday: 9am-5pm</li>
            <hr>
            <li>Thursday: 9am-2pm</li>
            <hr>
            <li>Friday: Off</li></b>
            <hr>
            <a href="Librarian-Dashboard.php"><button type="button">Back</button></a>
        </ul>
        </form>
        </body>
    </html>

