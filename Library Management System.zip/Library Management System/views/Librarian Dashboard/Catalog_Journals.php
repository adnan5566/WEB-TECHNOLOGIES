<!DOCTYPE html>
	<html>
		<head>
			<title>Journal Cataloging</title>
			<link rel="stylesheet" href="LibrarianDashboard.css">
		</head>

		<body>
			<fieldset><legend><h1>Journal Cataloging</h1></legend>
			<table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>
			
			<table>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
            	<tr>
                	<td><h2></h2></td>
            	</tr>
        	</table>
			<form name = "catalogJournalForm" method="POST" action="../../controllers/Catalog_Journalshendlar.php" onsubmit="return validateForm()">
		            <label for="title"><b>Journal Title:</b></label>
		            <input type="text" id="title" name="title"><br><br>
					<label for="publisher"><b>Publisher:</b></label>
		            <input type="text" id="publisher" name="publisher"><br/>

		            <label for="volume"><b>Volume:</b></label>
		            <input type="text" id="volume" name="volume"><br/>

		            <label for="issue"><b>Issue:</b></label>
		            <input type="date" id="issue" name="issue"><br/>

                    
					<label for="CIPN"><b>Cataloged In Page No.</b></label>
					<input type="text" id="CIPN" name="CIPN"><br/>
					<input type="button" name="click" value="Check" onclick="ajax()">
		            <input type="submit" name="submit" value="Submit">
					<input type="reset" value="Reset">
					<a href="Catalog-Resource.php"><button class="back-button" type="button">Back</button></a>
	            </form>
		</body>
	</html>


	<script>
		function validateForm() {
			var title = document.catalogJournalForm.title.value;
			var publisher = document.catalogJournalForm.publisher.value;
			var volume = document.catalogJournalForm.volume.value;
			var issue = document.catalogJournalForm.issue.value;
			var cipn = document.catalogJournalForm.CIPN.value;


			if (title == null || title == "") {
				alert("Please enter a title.");
				return false;
			}

			if (publisher ==  null || publisher == "") {
				alert("Please enter a publisher.");
				return false;
			}

			if (volume == null || volume == "") {
				alert("Please enter a volume.");
				return false;
			}

			if (issue == null || issue == "") {
				alert("Please enter an issue.");
				return false;
			}

			if (cipn == null || cipn == "") {
				alert("Please enter a Cataloged In Page No.");
				return false;
			}
		}


		function ajax (){
			var title = document.catalogJournalForm.title.value;
			var publisher = document.catalogJournalForm.publisher.value;
			var volume = document.catalogJournalForm.volume.value;
			var issue = document.catalogJournalForm.issue.value;
			var cipn = document.catalogJournalForm.CIPN.value;
            
            let data = {
                'title' : title,
                'publisher' : publisher,
                'volume' : volume,
                'issue' : issue,
                'cipn' :cipn

            };
            let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="title : "+info.title;
                document.getElementsByTagName('h2')[1].innerHTML ="publisher : " +info.publisher;
                document.getElementsByTagName('h2')[2].innerHTML ="volume : "+info.volume;
                document.getElementsByTagName('h2')[3].innerHTML ="issue :" +info.issue;
                document.getElementsByTagName('h2')[4].innerHTML ="cpin : "+info.cipn;
                
            }
        }

    }
	</script>