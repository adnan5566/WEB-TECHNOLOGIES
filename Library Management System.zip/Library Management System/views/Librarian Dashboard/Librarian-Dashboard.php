<!DOCTYPE html>
<html>
	<head>
	<title>Librarian-Dashboard </title>
	<link rel="stylesheet" href="LibrarianDashboard.css">
    </head>
    <body>
	<fieldset>
            <table width = "800">
                <tr>
                    <td>
                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                    </td>
                </tr>    
            </table>
			<legend><h1>Welcome To Librarian </h1></legend>
                
	<form>
		<fieldset>
		<legend>Assignn Task</legend>
			<p> <a href="Catalog-Resource.php"><b>Catalog-Resource</b></a> </p>
		</fieldset>
		<fieldset>
		<legend>Resource </legend>
			<p> <a href="resource_allocation.php"><b>Allocation</b></a> </p>
		</fieldset>
        <fieldset>
            <legend>Content</legend>
            <a href="../Content\RemoveUser.php">Remove User</a><br>
            <a href="../Content\RemoveBook.php">Remove Book</a>
        </fieldset>
        <fieldset>
            <legend>Book Management</legend>
            <a href="../BookManagement\Acquisition\AddNewBook.php">AddNewBook</a><br>
            <a href="../BookManagement\Acquisition\AddNewJournal.php">AddNew Journal</a><br>
            <a href="../BookManagement\Circulation\CircularBook.php">CircularBook</a><br>
        </fieldset>
        <fieldset>
            <legend>View Profile</legend>
            <a href="../ViewProfile\MemberInformationView.php">ViewProfile</a><br/>
			<a href="work-schedule.php">Work Schedule</a>
        </fieldset>
        <fieldset>
            <legend>Trending</legend>
            <a href="../Trending\mostPolularBook\mostpopularbook.php">Most Popular Item</a>
        </fieldset>
        <fieldset>
            <legend>Logout</legend>
            <a href="../../controllers/logout.php">LogOut</a>
        </fieldset>

	</form>
	</fieldset>



</body>
</html>