<html>
    <h1>'Journal Cataloged Successfully'</h1>
</html>