<!DOCTYPE html>
<html>
<head>
    <title>Add Fine</title>
    <link rel="stylesheet" href="addFine.css">
    <script>
        function validateForm() {
            const payment_method = document.fineForm.payment_method;
            const phone_number = document.fineForm.phone_number;
            const amount = document.fineForm.amount;
            const pin = document.fineForm.pin;

            if (payment_method.value.trim() === "") {
                alert("Payment Method must be selected");
                payment_method.focus();
                return false;
            }

            if (phone_number.value.trim() === "" || phone_number.value.length !== 11) {
                alert("Phone Number must be filled out & the number need to be valid like 11 digits!");
                phone_number.focus();
                return false;
            }

            if (amount.value.trim() === "" || amount.value <= 0) {
                alert("Amount must be filled out and greater than zero");
                amount.focus();
                return false;
            }

            if (pin.value.trim() === "") {
                alert("PIN must be filled out");
                pin.focus();
                return false;
            }

            return true;
        }

        function refreshPage() {
            location.reload();
        }
    </script>
</head>
<body>
    <fieldset>
        <legend><h1>Add Fine</h1></legend>
    <form name="fineForm" action="../controllers/fineController.php" method="post" onsubmit="return validateForm()">
        <label for="payment_method">Payment Method:</label>
        <select name="payment_method" id="payment_method">
            <option value="">Select Payment Method</option>
            <option value="bkash">Bkash</option>
            <option value="nagad">Nagad</option>
            <option value="rocket">Rocket</option>
        </select>
        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number">
        <label for="amount">Amount:</label>
        <input type="number" id="amount" name="amount">
        <label for="pin">PIN:</label>
        <input type="password" id="pin" name="pin">
        <input type="submit" name="submit" value="Submit"> <br>
        <button type="button" onclick="refreshPage()">Refresh</button>
    </form>
    </fieldset>
</body>
</html>
