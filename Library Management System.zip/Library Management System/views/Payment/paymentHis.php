<?php
session_start();
require_once('../../models/paymentModel.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lc_id = validate_input($_POST['lc_id']);
    $payment_history = get_payment_history($lc_id);
}

function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<html>
<head>
    <title>Payment History</title>
    <link rel="stylesheet" href="payment.css">
</head>
<body>
    <fieldset>
    <h2>Payment History</h2>
    <?php if (isset($payment_history)): ?>
        <?php if (count($payment_history) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Payment Method</th>
                        <th>Reason</th>
                        <th>Amount</th>
                        <th>Phone Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payment_history as $payment): ?>
                        <tr>
                            <td><?= $payment['payment_method'] ?></td>
                            <td><?= $payment['reason'] ?></td>
                            <td><?= $payment['amount'] ?></td>
                            <td><?= $payment['phone_number'] ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No payment history found for the provided LC ID.</p>
        <?php endif ?>
    <?php endif ?>
        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
        </table>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="return validateForm();">
        LC ID: <input type="text" name="lc_id"><br/>
        <input type="submit" value="Get Payment History">
        <input type="button" name="click" value="Check" onclick="ajax()">
    </form>
        </fieldset>
</body>
</html>



    <script>
        function validateForm() {
        var lc_id = document.getElementsByName('lc_id')[0].value;
 
        let lcid = /^LC-\d{4}$/;
        
            if (lc_id == "" || !lcid.test(lc_id)) {
                alert("Please enter a valid Library-Card ID (e.g. LC-XXXX)");
                return false;
            }
            return true;
        }

        function ajax (){
            var lc_id = document.getElementsByName('lc_id')[0].value;
                
                let data = {
				 'lc_id' : lc_id,
                }


			let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="lc_id : "+info.lc_id;
                
			}
		}
    }
    </script>

