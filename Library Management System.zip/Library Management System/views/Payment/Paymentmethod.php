<!DOCTYPE html>
<html>
<head>
    <title>Payment</title>
    <link rel="stylesheet" href="payment.css">
</head>
<body>
    <fieldset>
        <legend><h1>Payment</h1></legend>
                <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
        <?php
        if (isset($_SESSION['payment_error'])) {
            echo '<p>' . $_SESSION['payment_error'] . '</p>';
            unset($_SESSION['payment_error']);
        }
        if (isset($_SESSION['payment_success']) && $_SESSION['payment_success']) {
            echo '<p>Payment successful!</p>';
            unset($_SESSION['payment_success']);
        }
        ?>
        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
        </table>

        
        <form name="paymentForm" method="post" action="../../controllers/paymentCheck.php" onsubmit="return validateForm();">
            <label for="lc_id"><b>Library Card ID:</b></label>
            <input type="text" name="lc_id" id="lc_id"><br>
            <label for="phone_number"><b>Phone Number:</b></label>
            <input type="text" name="phone_number" id="phone_number"><br>
            <label for="pin"><b>PIN:</b></label>
            <input type="password" name="pin" id="pin"><br>
            <label for="payment_method"><b>Payment Method:</b></label>
            <select name="payment_method" id="payment_method">
                <option value=""><b>Select Payment Method</b></option>
                <option value="bkash"><b>Bkash</b></option>
                <option value="nagad"><b>Nagad</b></option>
                <option value="rocket"><b>Rocket</b></option>
            </select><br>
            <label for="reason"><b>Reason for Payment:</b></label>
            <select name="reason" id="reason">
                <option value=""><b>Select Reason</b></option>
                <option value="Card Renewal"><b>Renew Card</b></option>
                <option value="buy_books"><b>Buy Books</b></option>
                <option value="fine"><b>Fine</b></option>
                <option value="lost_book"><b>Lost Book</b></option>
                <option value="other"><b>Other</b></option>
            </select><br>
            <label for="amount">Amount:</label>
            <input type="text" name="amount" id="amount"><br/>
            <input type="button" name="click" value="Check" onclick="ajax()">
            <input type="submit" value="Pay">
            <input type="reset" value="Reset"><br>
        </form>
    </fieldset>

    <script>
        function validateForm() {
            var lc_id = document.paymentForm.lc_id.value;
            var phone_number = document.paymentForm.phone_number.value;
            var pin = document.paymentForm.pin.value;
            var payment_method = document.paymentForm.payment_method.value;
            var reason = document.paymentForm.reason.value;
            var amount = document.paymentForm.amount.value;


            let lcid = /^LC-\d{4}$/;
            let phone_no = /^01\d{9}$/;
            let amount_pay = /^\d+(\.\d{1,2})?$/;


            
            if (lc_id == "" || !lcid.test(lc_id)) {
                alert("Please enter a valid Library-Card ID (e.g. LC-XXXX)");
                return false;
            }
            if (phone_number == "" || !phone_no.test(phone_number)) {
                alert("Please enter a valid Phone Number (11 digits starting with 01)");
                return false;
            }
            if (pin == "" || pin.length != 4) {
                alert("Please enter a 4-digit PIN");
                return false;
            }
            if (payment_method == "") {
                alert("Please select Payment Method");
                return false;
            }
            if (reason == "") {
                alert("Please select Reason for Payment");
                return false;
            }
            if (amount == "" || !amount_pay.test(amount)) {
                alert("Please enter a valid Amount (e.g. 100)");
                return false;
            }

            return true;
        }


        function ajax (){
            var lc_id = document.paymentForm.lc_id.value;
            var phone_number = document.paymentForm.phone_number.value;
            var pin = document.paymentForm.pin.value;
            var payment_method = document.paymentForm.payment_method.value;
            var reason = document.paymentForm.reason.value;
            var amount = document.paymentForm.amount.value;
            
            let data = {
                'lc_id' : lc_id,
                'phone_number' : phone_number,
                'pin' : pin,
                'payment_method' : payment_method,
                'reason' : reason,
                'amount' : amount

            };
            let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="lc_id : "+info.lc_id;
                document.getElementsByTagName('h2')[1].innerHTML ="phone_number : " +info.phone_number;
                document.getElementsByTagName('h2')[2].innerHTML ="pin : "+info.pin;
                document.getElementsByTagName('h2')[3].innerHTML ="payment_method :" +info.payment_method;
                document.getElementsByTagName('h2')[4].innerHTML ="reason : "+info.reason;
                document.getElementsByTagName('h2')[5].innerHTML ="amount : " +info.amount;
            }
        }

    }
        
    </script>