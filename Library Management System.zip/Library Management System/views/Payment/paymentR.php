<html>
    <h1>Money received and Your Card Renewed Successfully</h1>
</html>