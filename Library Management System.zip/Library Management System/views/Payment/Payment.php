<!DOCTYPE html>
<html>
<head>
	<title>Payment </title>
	<link rel="stylesheet" href="payment.css">
</head>
<body>
	<fieldset>
	<legend><h1>Payment</h1></legend>
	<table width = "800">
            	<tr>
                	<td>
                    	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
               	 	</td>
            	</tr>    
        	</table>

	

	<h2><p> <a href="Paymentmethod.php">Pay Online</a> </p></h2>


	<h2><p> <a href="paymentHis.php">Payment History</a> </p></h2>

	
	<p>If you have any questions or facing payment releted problem, please don't hesitate to contact us by email.</p>

	<p>Click <a href="../Help & Support/emailsupport.php">here</a> to access our email support form.</p>

	<a href="../Adnan.php"><button type="button"><b> Back </b></button></a>
</fieldset>

</body>
</html>