<!DOCTYPE html>
<html>
<head>
    <title>Library Card </title>
    <link rel="stylesheet" href="LibraryCard.css">
</head>
<body>
    <fieldset>
	<legend><h1>Library Card </h1></legend>
                <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
    <form>
    <ul>
        <li><a href="LC.php"><b>Issue a new card</b></a></li>
        <li><a href="../Payment/Paymentmethod.php"><b>Renew a card</b></a></li>
        <li><a href="CardReplacement.php"><b>Replace a card</b></a></li>
        <li><a href="Card Re_de.php"><b>Deactivate/Reactivate a card</b></a></li>
		<p>If you have any questions or facing Laibrary Card releted problem, please don't hesitate to contact us by email.</p>

		<p>Click <a href="../Help & Support/emailsupport.php"><b>here</b></a> to access our email support form.</p>
    </ul>
        <a href="../Adnan.php"><button type="button"><b> Back </b></button></a>
    </form>
    </fieldset>
</body>
</html>
