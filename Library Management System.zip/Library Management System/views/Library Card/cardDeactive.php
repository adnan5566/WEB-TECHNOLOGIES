<!DOCTYPE html>
  <html>
    <head>
      <title>Deactivate Card</title>
      <link rel="stylesheet" href="LibraryCard.css">
    </head>
    <body>
      <fieldset>
        <legend><h1>Deactivate Card</h1></legend>
              <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
        </table>
        <form method="POST" action="../../controllers/CardDeactivateHendlar.php" onsubmit="return validateForm();">
          <label for="card_number"><b>Card Number:</b></label>
          <input type="text" id="card_number" name="card_number">
          <br/>
          <input type="button" name="click" value="Check" onclick="ajax()">
          <button type="submit" name="submit">Deactivate</button>
        </form>
      </fieldset>
    </body>
  </html>

  
  <script>
    function validateForm() {
      var cardNumber = document.getElementById('card_number').value;
      let cardnumber = /^LC-\d{4}$/;
      if (cardNumber == "" || !cardnumber.test(cardNumber)) {
        alert("Invalid card number format. Please use the format LC-4digit");
        return false;
      }
    }

    function ajax (){
      var cardNumber = document.getElementById('card_number').value;
                
          let data = {
				    'cardNumber' : cardNumber,
                }


			    let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="cardNumber : "+info.cardNumber;
                
			  }
		  }
    }

  </script>
