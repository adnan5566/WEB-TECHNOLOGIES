
<!DOCTYPE html>
<html>
<head>
    <title>Library Card Issuance</title>
    <link rel="stylesheet" href="LibraryCard.css">
</head>
<body>
    <fieldset>
        <legend><h1>Library Card Issuance</h1></legend>
                <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
        <table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            
        </table>
        <form name="libraryCardForm" method="post" action="../../controllers/LibraryCardHendlar.php" onsubmit="return validateForm()">
            <label><b>User ID:</b></label>
            <input type="text" name="userid"><br/>
            <label><b>Email:</b></label>
            <input type="text" name="email"><br/>
            <input type="button" name="click" value="Check" onclick="ajax()">
            <input type="submit" name="submit" value="Generate Library Card">
			<input type="reset" value="Reset"><br/>
        </form>
    </fieldset>
</body>
</html>



    <script>
        function validateForm() {
            var userid = document.libraryCardForm.userid.value;
            var email = document.libraryCardForm.email.value;

            let userId =  /^U-\d{4}$/;
            let emailVal = /^\S+@\S+\.\S+$/;


            
            if (userid == "" || !userId.test(userid)) {
                alert("Please enter a valid Library-Card ID (e.g. U-XXXX)");
                return false;
            }

       

    	    if (email == "" || !emailVal.test(email)) {
                alert("Please enter a valid email address");
                return false;
            }

        }

        function ajax (){
            var userid = document.libraryCardForm.userid.value;
            var email = document.libraryCardForm.email.value;
                
                let data = {
				 'userid' : userid,
                 'email' :  email
                };


			let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="userid : "+info.userid;
                document.getElementsByTagName('h2')[1].innerHTML ="email : "+info.email;
                
			}
		}
    }
    </script>