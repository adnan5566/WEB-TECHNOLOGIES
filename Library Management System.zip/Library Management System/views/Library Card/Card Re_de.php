<!DOCTYPE html>
<html>
<head>
    <title>Library Card </title>
    <link rel="stylesheet" href="LibraryCard.css">
</head>
<body>
    <fieldset>
	<legend><h1>Reactivate/Deactivate Card </h1></legend>
                <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
    <form>
    <ul>
        <li><a href="cardDeactive.php"><b>Deactivate Library Card</b></a></li>
        <li><a href="card_reactivation.php"><b>Reactivate Library Card</b></a></li>
		<p>If you have any questions or facing Laibrary Card releted problem, please don't hesitate to contact us by email.</p>

		<p>Click <a href="../Help & Support/emailsupport.php"><b>here</b></a> to access our email support form.</p>
    </ul>
        <a href="../Adnan.php"><button type="button"><b> Back </b></button></a>
    </form>
</body>
</html>
