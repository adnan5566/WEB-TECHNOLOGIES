<!DOCTYPE html>
<html>
  <head>
    <title>Card Replacement</title>
    <link rel="stylesheet" href="LibraryCard.css">
  </head>
  <body>
    <fieldset>
      <legend><h1>Card Replacement</h1></legend>
              <table width = "800">
                	<tr>
                    	<td>
                        	<img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                   	 	</td>
                	</tr>    
            	</table>
      <?php if(!empty($errors)): ?>
        <div>
          <?php foreach($errors as $error): ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <table>
            <tr>
                <td><h2></h2></td>
            </tr>
            <tr>
                <td><h2></h2></td>
            </tr>
            
        </table>
      <form method="POST" action="../../controllers/cardRepleceHendlar.php" onsubmit="return validateForm();">
        <label for="card_number"><b>Card Number:</b></label>
        <input type="text" id="card_number" name="card_number" value="<?php echo isset($_POST['card_number']) ? $_POST['card_number'] : ''; ?>">
        <br/>
        <label for="replacement_reason"><b>Reason for Replacement:</b></label>
        <textarea id="replacement_reason" name="replacement_reason"><?php echo isset($_POST['replacement_reason']) ? $_POST['replacement_reason'] : ''; ?></textarea>
        <br/>
        <input type="button" name="click" value="Check" onclick="ajax()">
        <button type="submit" name="submit"><b>Submit</b></button>
      </form>
    </fieldset>
  </body>
</html>



    <script>
      function validateForm() {
        var cardNumber = document.getElementById("card_number").value;
        var reason = document.getElementById("replacement_reason").value;
        
        let cardnumber = /^LC-\d{4}$/;
        
        if (cardNumber == "" || !cardnumber.test(cardNumber)) {
        alert("Invalid card number format. Please use the format LC-4digit");
        return false;
        }
        
        if (reason == "" || reason.trim().length < 1) {
        	alert("Please enter your valid reason");
        	return false;
    	  }
        
        return true;
      }


        function ajax (){
          var cardNumber = document.getElementById("card_number").value;
          var reason = document.getElementById("replacement_reason").value;
                
              let data = {
				          'cardNumber' : cardNumber,
                  'reason' :  reason
                }


			      let info = JSON.stringify(data);

            let xhttp = new XMLHttpRequest();

            xhttp.open('post', 'server.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('data=' + info);

            xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                let info = JSON.parse(this.responseText);
                document.getElementsByTagName('h2')[0].innerHTML ="cardNumber: "+info.cardNumber;
                document.getElementsByTagName('h2')[1].innerHTML ="reason : "+info.reason;
                
			        }
		        }
        }
    
    </script>
