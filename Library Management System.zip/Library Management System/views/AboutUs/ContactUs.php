<html>
    <head>
        <title>ContactUs</title>
    </head>
    <body>
        <center>
                <table width=1080>
                    <tr height=70>
                        <td >
                            <table width = "800">
                                <tr>
                                    <td>
                                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                                    </td>
                                    <td>
                                        <h3>AIUB Library</h3>
                                    </td>
                                    <td align="right">
                                        <!-- <a href="UserManagement\UserManagement.php">UserManagement</a>
                                        <a href="">BookManagement</a>
                                        <a href="">ViewProfile</a>
                                        <a href="">Trending</a> -->
                                        <a href="/Joydep_Web_Technologies\WelcomePage.php">back</a>
                                    </td>   
                                </tr>    
                            </table>                   
                        </td>
                    </tr>
                </table>
        </center>
        <fieldset>
            <legend>
                Contact Information
                </legend>
                <h2>Massage Received</h2></br>
                <hr>
                <h3>For any further issues <br>
                 contact us <br> 
                 Library Office!</br>
                <br>
                Call us
                <br>Contact No: 01********* 
                <br>Phone No: 01**********
                </h3>
                </br>
                <h2>Thank You</h2>
        </fieldset> 
        <footer align="Center"><h4>Copyright ©JoyDep_Dhar_2023</h4> </footer>   
    </body>
</html>