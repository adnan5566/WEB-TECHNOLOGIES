<body>
    <head>
        <title>AboutUs</title>
    </head>
<body>
        <center>
                <table width=1080>
                    <tr height=70>
                        <td >
                            <table width = "800">
                                <tr>
                                    <td>
                                        <img height="120" src="/Joydep_Web_Technologies\LibraryLogo.jpg">
                                    </td>
                                    <td>
                                        <h3>AIUB Library</h3>
                                    </td>
                                    <td align="right">
                                        <!-- <a href="UserManagement\UserManagement.php">UserManagement</a>
                                        <a href="">BookManagement</a>
                                        <a href="">ViewProfile</a>
                                        <a href="">Trending</a> -->
                                        <a href="/Joydep_Web_Technologies\WelcomePage.php">back</a>
                                    </td>   
                                </tr>    
                            </table>                   
                        </td>
                    </tr>
                </table>
        </center>
        <fieldset>
            <legend>Library Information</legend>
                <h3>About the Library</h3>
                <p>Welcome to our library! We offer a wide range of books, periodicals, and other resources for students, faculty, and staff. Our library is open to everyone, and we strive to create a welcoming and inclusive space for all members of our community.</p>
                <h3>Hours of Operation</h3>
                <p>Our library is open during the following hours:</p>
                <ul>
                    <li>Saturday-Thursday: 9am-8pm</li>
                    <li>Friday: 10am -5pm</li>
                </ul>
        </fieldset>
        <fieldset>
            <legend>Library Policies</legend>
                <p>We have a few policies in place to ensure that everyone can use our library resources effectively and efficiently:</p>
                <ul>
                    <li>All library materials must be checked out using a valid library card.</li>
                    <li>Books may be checked out for up to 2 weeks at a time.</li>
                    <li>Overdue materials will accrue a fine of $0.50 per day.</li>
                    <li>Lost or damaged materials will be subject to replacement fees.</li>
                </ul>
        </fieldset>
        <fieldset>
            <legend>
            Contact Information
            </legend>
            <p>If you have any questions or concerns, please feel free to contact us:</p>
            <ul>
                <li>Phone: 555-1234</li>
                <li>Email: library@university.edu</li>
                <li>Address: 123 Dhaka, Bangladesh</li>
            </ul>
        </fieldset>  
        <footer align="Center"><h4>Copyright ©JoyDep_Dhar_2023</h4> </footer>  
    </body>
</html>