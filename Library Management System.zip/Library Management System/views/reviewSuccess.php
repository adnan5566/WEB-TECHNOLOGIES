<!DOCTYPE html>
<html>
<head>
    <title>Review Success</title>
    <link rel="stylesheet" href="reviewSuccess.css">
</head>
<body>
    <h1>Review Added Successfully</h1>
    <p>Your review has been submitted successfully!</p>
    <a href="addReview.php">Add another review</a>
</body>
</html>
