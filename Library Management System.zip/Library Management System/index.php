<!DOCTYPE html>
<html lang="en">

    <head>
        <title>welcome</title>
    </head>

    <body>
        <?php 
            header('location: views/welcomepage.php');
        ?>
    </body>

</html>