<?php
require_once '../models/review.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book_name = $_POST["book_name"];
    $rating = $_POST["rating"];
    $review = $_POST["review"];
    $email = $_POST["email"];

    if (addReview($book_name, $rating, $review, $email)) {
        header("Location: ../views/reviewSuccess.php");
    } else {
        header("Location: ../views/reviewFailure.php");
    }
}
?>
