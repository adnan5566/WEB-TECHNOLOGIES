<?php

require_once '../models/event.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'view';

$event = new event();

switch ($action) {
    case 'create':
        $title = $_POST['title'];
        $description = $_POST['description'];
        $result = $event->createevent($title, $description);
        if ($result) {
            header('Location: -index.php');
        }
        break;
    case 'delete':
        $id = $_POST['id'];
        //$result = $event->deleteevent($id);
        if ($result) {
            header('Location: -index.php');
        }
        break;
    default:
        $events = $event->getevents();
        break;
}

?>