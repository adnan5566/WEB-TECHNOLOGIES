<!-- <?php
//     require_once "../models/usermodels.php";
//     session_start();
// //    $username=$_REQUEST("username");
// $username = $_GET['username'];
//    echo$username;
//    $status=getUser($username);
//    if($status){ 
//                     echo"successfully";
//                 header('location: ../views/ViewProfile/AdminAccount.php');
//             }else{
//                 echo "DB error, try again";
//             } 
            
    ?> -->