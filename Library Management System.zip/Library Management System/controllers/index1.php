<?php

require_once '../models/report.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'view';

$report = new Report();

switch ($action) {
    case 'create':
        $title = $_POST['title'];
        $description = $_POST['description'];
        $result = $report->createreport($title, $description);
        if ($result) {
            header('Location: -index.php');
        }
        break;
    case 'delete':
        $id = $_POST['id'];
        
        if ($result) {
            header('Location: -index.php');
        }
        break;
    default:
        $reports = $report->getreports();
        break;
}

?>