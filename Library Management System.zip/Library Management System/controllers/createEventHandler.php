<?php
require_once '../models/event.php';

$Event = new Event();

$title = $_POST['title'];
$description = $_POST['description'];

$result = $Event->createEvent($title, $description);

if ($result) {
    header('Location: -index.php');
} else {
    echo 'Failed to create Event.';
}

?>

