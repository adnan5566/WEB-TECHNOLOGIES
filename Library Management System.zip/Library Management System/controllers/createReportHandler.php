<?php

require_once '../models/report.php';

$report = new Report();

$title = $_POST['title'];
$description = $_POST['description'];

$result = $report->createReport($title, $description);

if ($result) {
    header('Location: index1.php');
} else {
    echo 'Failed to create report.';
}

?>
