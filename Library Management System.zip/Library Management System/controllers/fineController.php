<?php

require_once '../models/fine.php';

if (isset($_POST['submit'])) {
    $payment_method = $_POST['payment_method'];
    $phone_number = $_POST['phone_number'];
    $amount = $_POST['amount'];
    $pin = $_POST['pin'];

    if (addFine($payment_method, $phone_number, $amount, $pin)) {
        header('Location: ../views/viewFines.php');
    } else {
        echo "Error: Could not add fine";
    }
}

?>



<link rel="stylesheet" href="../views/viewFine.css">
