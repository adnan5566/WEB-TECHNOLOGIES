<html>
    <head>
        <title>
            ForgetPassword
        </title>
    </head>
    <body>
        <table width=1440>
                <tr height=70>
                    <td >
                        <table width = "1440">
                            <tr>
                                <td>
                                    <img height="120" src="LibraryLogo.jpg">
                                </td>
                                <td align="right">
                                    <a href="WelcomePage.php">Home</a> 
                                    <a href="login.php">| SignIn</a>   
                                    <a href="reg.php">| SignUp</a>  
                                </td>    
                            </tr>    
                        </table>                   
                    </td>
                </tr>
        </table>
        <fieldset>
            <legend align="Center"><h3>Forget Password</h3></legend>
            Enter Email Account: <input type="text" name="UserID">
            <button>Submit</button>

        </fieldset>
    </body>
</html>
