<?php
require_once('../models/favourite.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $available_copies = $_POST['available_copies'];

    if (addfavourite($title, $author, $isbn, $available_copies)) {
        header('Location: ../views/show_favourite.php');
    } else {
        echo 'Error adding favourite';
    }
}
?>
